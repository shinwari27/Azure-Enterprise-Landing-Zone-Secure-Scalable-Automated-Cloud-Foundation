\# Phase 0 – Company Overview



\## Administrative Roles



| Role                             | Count | Purpose |

|-----------------------------|--------|--------|

| Global Administrator  | 2        | Full tenant control |

| Subscription Owner     | 1        | Billing \& subscription management |

| User Administrator      | 1        | User lifecycle management |

| Break-Glass Admin     | 1        | Emergency access only |



\## Organization Size

\- Total users: 45

\- Regular users: 40

\- Admin users: 5



\## Departments

\- Sales (10 users)

\- IT (10 users)

\- Marketing (10 users)

\- HR (10 users)



\## Cloud Goal

\- Migrate from on-prem to Azure

\- Follow Zero Trust security

\- Use least-privilege RBAC

\- High availability and scalability

\- Cost-controlled environment



\## Identity Model



\- Azure Entra ID used as identity provider

\- Department-based security groups

\- RBAC assigned to groups (not users)

\- MFA enforced for all users

\- Conditional Access policies applied



\## Management Group Hierarchy



Tenant Root

│

├── Platform

├── Security

├── Production

├── Non-Production

└── Sandbox



Purpose:

\- Policy inheritance

\- RBAC inheritance

\- Cost management





\## Subscription Strategy



| Subscription    |    Purpose |

|-------------------|--------------|

| Platform-Sub  | Networking, shared services |

| Security-Sub   | Defender, monitoring |

| Prod-Sub         | Production workloads |

| NonProd-Sub  | Testing |

| Sandbox-Sub  | Experiments |





\## Networking Architecture



\- Hub-Spoke topology

\- One Hub VNet for shared services

\- One Spoke VNet per department

\- Each Spoke VNet has:

&nbsp; - App subnet

&nbsp; - VM subnet

\- NSGs applied at subnet level

\- UDRs for controlled traffic





\## Naming Convention



Format:

<resource>-<department>-<environment>-<region>



Examples:

\- vnet-sales-prod-cc

\- vm-it-prod-cc

\- rg-hr-compute-prod







\## Mandatory Tags



\- Department

\- Owner

\- Environment

\- CostCenter

\- DataClassification













